const express = require('express');
const path = require('path');
const database = require('../config/database');
const router = express.Router();

router.get('/', (req, res)=> {
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "metal"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            //console.log( res.json(documents))
            res.render('index', {posts: documents});

        }
    }); 
})

router.get('/metal_posts', (req, res)=>{
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "metal"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.json(documents);
        }
    });
})

//Creating METAL GENRE POSTS
router.post('/posts', (req, res)=>{
    const collection = 'posts';
    const user_data = req.body;
    const title = user_data.title;
    const description = user_data.description;
    const genre = "metal";

    database.getDB().collection(collection).insertOne({
        'title': title,
        'description': description,
        'genre': genre,
    }, (err, result)=>{
        if(err){
            console.log(err);
        }else {
            //res.json({result : result, document : result.ops[0]})
            res.redirect('/');
        }
    })
});

//Adding Comments
router.post('/:id/comments', (req, res)=>{
    const collection = 'comments';
    const PostID = req.params.id;
    const user_data = req.body;
    //comment = user_data.comment;
    comment = "";
    console.log(PostID)
    console.log(comment);

    //Inserting Data in Comments Document
    database.getDB().collection(collection).insertOne({
        'comment': comment,
        'post_id': PostID,
    }, (err, result)=>{
        if(err){
            console.log(err);
        }else {
            res.redirect('/')
        }
    })
});

//Loading Comments
router.get('/:id/comments', (req, res)=>{
    const collection = 'comments';
    const PostID = req.params.id;
    database.getDB().collection(collection).find({"post_id": PostID}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.json(documents);
        }
    })

})


//ROCK POSTS
router.get('/rock_posts', (req, res)=>{
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "rock"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.json(documents);
        }
    });
})

//GENRE ROCK
router.get('/rock', (req, res)=> {
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "rock"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.render('rock', {posts: documents});

        }
    });
})

//GENRE METAL
router.get('/metal', (req, res)=> {
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "metal"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.render('metal', {posts: documents});

        }
    });
})

//GENRE HIPHOP
router.get('/hiphop', (req, res)=> {
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "hiphop"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.render('hiphop', {posts: documents});

        }
    });
})

//GENRE EDM
router.get('/edm', (req, res)=> {
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "edm"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.render('edm', {posts: documents});

        }
    });
})

//GENRE COUNTRY
router.get('/country', (req, res)=> {
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "country"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.render('country', {posts: documents});

        }
    });
})

//GENRE ALTERNATIVE
router.get('/alternative', (req, res)=> {
    const collection = 'posts';
    database.getDB().collection(collection).find({"genre": "alternative"}).toArray((err, documents)=>{
        if(err){
            console.log(err)
        }else{
            console.log(documents);
            res.render('alternative', {posts: documents});

        }
    });
})


//Creating ROCK GENRE POSTS
router.post('/rock/new', (req, res)=>{
    const collection = 'posts';
    console.log("REQUEST DATA")
    console.log(req.body)
    //console.log(req.body.title)
    //const title = req.body.title;
    //const description = req.body.description;
    const genre = "rock";
    title="";
    description ="";
    database.getDB().collection(collection).insertOne({
        'title': title,
        'description': description,
        'genre': genre,
    }, (err, result)=>{
        if(err){
            console.log(err);
        }else {
            //res.json({result : result, document : result.ops[0]})
            res.redirect('/rock')
        }
    })
});



module.exports = router;