const express = require('express');
const bodyParser = require('body-parser');
const postRouter = require('./routes/posts');
const app = express();

app.set('view engine', 'ejs');
//app.use(bodyParser.json());
app.use('/', postRouter);
app.use(express.urlencoded({extended: false}))
const path = require('path');
const database = require('./config/database');
const collection = 'posts';
//PORT
const port = 5000;

//conneting to DB
database.connect((err)=>{
    if (err){
        console.log('Unable to Connect to database');
        process.exit(1);
    }else{
        app.listen(port, ()=>{
            console.log("Connection to db Success, Waiting....")
        })
    }
});