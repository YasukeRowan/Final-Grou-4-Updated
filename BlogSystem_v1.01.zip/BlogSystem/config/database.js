const MongoClient = require('mongodb').MongoClient;
const ObjectID = require('mongodb').ObjectID;
const dbname = 'movies';
const dbURL = 'mongodb://localhost:27017';
const mongoOptions= {
    useNewUrlParser: true,

}

const state = {
    database: null

}

const connect = (cb) => {
    if(state.database){
        cb();
    }else{
        MongoClient.connect(dbURL, mongoOptions, (err, client) => {
            if(err){
                cb(err);
            }else {
                state.database = client.db(dbname);
                cb();
            }
        });
    }
}

const getPrimaryKey = (_id) => {
    return ObjectID(_id);
}

const getDB = ()=>{
    return state.database;
}

module.exports = {getDB, connect, getPrimaryKey};